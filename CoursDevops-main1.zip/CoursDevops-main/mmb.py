#method de salutation
def salutation(name="Moussa"):
    print(f"Bonjour {name}")


salutation()