prenom = "Vivien"
print(f'Bonjour {prenom} !')